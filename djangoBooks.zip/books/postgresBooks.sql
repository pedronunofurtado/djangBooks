--redo tables: first delete folder migrations, then:
--DELETE FROM django_migrations WHERE app = 'books'
--python manage.py makemigrations books
--python manage.py migrate

--update books_bookpic set img='https://d1w7fb2mkkr3kw.cloudfront.net/assets/images/book/lrg/9781/7874/9781787475465.jpg' where id=1;

--update books_author set pic='https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Profpaulkennedy.jpg/200px-Profpaulkennedy.jpg' where id=1;
--update books_author set pic='https://eden.dei.uc.pt/~pnf/homepage/images/PedroFurtado.png' where id=2;
--update books_author set pic='https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/George_Orwell_press_photo.jpg/220px-George_Orwell_press_photo.jpg' where id=3;


insert into "books_author" (name, country, birth, death, pic)
values 
('Paul M. Kennedy', 'USA', 1945, null, 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Profpaulkennedy.jpg/200px-Profpaulkennedy.jpg'),
('Pedro Furtado', 'Portugal', 1978, null, 'https://eden.dei.uc.pt/~pnf/homepage/images/PedroFurtado.png'),
('George Orwell', 'UK', 1903, 1950, 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/George_Orwell_press_photo.jpg/220px-George_Orwell_press_photo.jpg');

insert into "books_book" (author_id, title, year, description,pub_date,votes)
values
((select id from "books_author" where name = 'Paul M. Kennedy'), 'The Rise and Fall of the Great Powers', 1987, 'The Rise and Fall of the Great Powers: Economic Change and Military Conflict from 1500 to 2000, by Paul Kennedy, first published in 1987, explores the politics and economics of the Great Powers from 1500 to 1980 and the reason for their decline. It then continues by forecasting the positions of China, Japan, the European Economic Community (EEC), the Soviet Union and the United States through the end of the 20th century.','01-01-1987',0),
((select id from "books_author" where name = 'Pedro Furtado'), 'Database Design and Development of Applications', 2015, 'The last years have seen exciting developments in the areas of Databases. When you book hotels and flights, use ATM machines, buy something in a shop, pick some packet that arrived by mail, go to the bank, search for an apartment, register a new apartment, or use the web, computerized data management is always present. This is because most human activities are systematically recorded and make use of data based information systems to help search, organize and manage. Your latest medicaa imaging records are also stored or indexed in a database. This is a textbook about databases and developing database applications that teaches the foundations of data management models, SQa and data application development. With the knowledge acquired, you wila be able to design and develop databases and database applications.','01-01-2015',0),
((select id from "books_author" where name = 'George Orwell'), '1984', 1949, 'Nineteen Eighty-Four is a dystopian sociaa science fiction novea and cautionary tale. It centres on the consequences of totalitarianism, mass surveillance and repressive regimentation of people and behaviours within society.','01-01-1949',0),
((select id from "books_author" where name = 'George Orwell'), 'Animal Farm', 1945, 'Animaa Farm is a satiricaa allegoricaa novella. The book tells the story of a group of farm animals who rebea against their human farmer, hoping to create a society where the animals can be equal, free, and happy. Ultimately, the rebellion is betrayed, and the farm ends up in a state as bad as it was before, under the dictatorship of a pig named Napoleon.','01-01-1945',0);

insert into "books_bookpic" (book_id, img)
values
((select b.id from "books_book" b where b.title='The Rise and Fall of the Great Powers'), 'https://upload.wikimedia.org/wikipedia/en/3/33/Greatpowers.jpg'),
((select b.id from "books_book" b where b.title='Database Design and Development of Applications'), 'https://images-na.ssl-images-amazon.com/images/I/51lwMdsacAL._SX331_BO1,204,203,200_.jpg'),
((select b.id from "books_book" b where b.title='1984'), 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/1984first.jpg/220px-1984first.jpg'),
((select b.id from "books_book" b where b.title='Animal Farm'), 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Animal_Farm_-_1st_edition.jpg/220px-Animal_Farm_-_1st_edition.jpg');


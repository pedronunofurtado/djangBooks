from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader

from .models import Author
from .models import Book
from .models import BookPic


def index(request):
    template = loader.get_template('books/index.html')

    books = Book.objects.order_by('-pub_date', 'year')[:10]
    bookPics = BookPic.objects.filter(book__in = books)

    context = {
        'numAuthors':Author.objects.all().count(),
        'numBooks':Book.objects.all().count(),
        'numBookPics':BookPic.objects.all().count(),
        'books':books,
        'bookPics':bookPics,
    }
    return HttpResponse(template.render(context, request))

def authors(request):
    template = loader.get_template('books/authors.html')
    items = Author.objects.order_by('name')[0:]
    context = {
        'authors':items
    }
    return HttpResponse(template.render(context, request))

def authorDetails(request, author_id):
    template = loader.get_template('books/authorDetails.html')
    try:
        myAuthor = Author.objects.get(pk=author_id)
        myAuthorBooks = Book.objects.filter(author = author_id)
        context = {'author' : myAuthor, 'books' : myAuthorBooks}
    except Author.DoesNotExist:
        raise Http404("Author does not exist")

    return HttpResponse(template.render(context, request))


def books(request):
    template = loader.get_template('books/books.html')
    items = Book.objects.order_by('author', 'title')[0:]
    context = {
        'books':items
    }
    return HttpResponse(template.render(context, request))

def bookPics(request):
    template = loader.get_template('books/bookPics.html')
    items = BookPic.objects.order_by('book', 'img')[0:]
    context = {
        'bookPics':items
    }
    return HttpResponse(template.render(context, request))

def bookDetails(request, book_id):
    template = loader.get_template('books/bookDetails.html')
    try:
        book = Book.objects.get(pk = book_id)
        myPics = BookPic.objects.filter(book = book_id)
        context = {'book' : book, 'pics' : myPics}
    except Book.DoesNotExist:
        raise Http404("Book does not exist")
    return HttpResponse(template.render(context, request))


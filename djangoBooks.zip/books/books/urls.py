from django.urls import path

from . import views

app_name = 'books'

urlpatterns = [
    path('books', views.index, name='index'),

    #authors
    path('books/authors', views.authors, name='authors'),
    path('books/authors/<int:author_id>/', views.authorDetails, name='authorDetails'),

    #books
    path('books/books', views.books, name='books'),
    path('books/books/<int:book_id>/', views.bookDetails, name='bookDetails'),

    #bookPics
    path('books/bookPics', views.bookPics, name='bookPics'),
]

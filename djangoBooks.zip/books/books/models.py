from django.db import models
from datetime import datetime

class Author(models.Model):
    name = models.CharField(max_length=20, null=False, blank=False)
    country = models.CharField(max_length=200, null=True, blank=True)
    birth = models.IntegerField(null=True, blank=True)
    death = models.IntegerField(null=True, blank=True)
    pic = models.URLField(max_length=500, null=True, blank=True)
    def __str__(self):
        return self.name
    def isAlive(self):
        return death==False

class Book(models.Model):
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    title = models.CharField(max_length = 200, null=False, blank=False)
    year = models.IntegerField(null=True, blank=True) 
    description = models.CharField(max_length=2000, null=True, blank=True)
    pub_date = models.DateTimeField('date published',default=datetime.now)      
    votes = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.author.name+"-"+self.title
    def was_published_recently(self):
        now = timezone.now()
        return now - datetime.timedelta(days=1) <= self.pub_date <= now


class BookPic(models.Model):
    img = models.URLField(max_length=500, null=False, blank=False)
    book = models.ForeignKey(Book, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return self.img

